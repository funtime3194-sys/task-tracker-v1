# Task Tracker V20

V20 is a personal offline-first task tracker built for Android phones.

## Major changes
- Redesigned Today, Month, Stats, Tasks and More screens.
- Correct status-bar and navigation-bar inset handling for modern Android.
- SQLite database with migration from the V19 database.
- Legacy SharedPreferences migration retained.
- Recurrence-aware statistics: Once, Daily, Weekly and Monthly tasks only count when scheduled.
- Daily percentage = completed applicable tasks / total applicable tasks.
- Future dates are not included in monthly averages.
- Task performance uses completed applicable days / applicable days.
- Fixed screen-scroll reset so switching tabs cannot leave a chart/header overlay.
- Improved task cards, matrix, charts, search and filters.
- Reminders are recreated after reboot or app replacement.
- Backup format accepts V19 and V20 files.

## GitHub build
The included workflow expects `TaskTracker_V20_Android_Project.zip` at repository root and produces `TaskTracker-V20-APK`.
