package com.example.tasktracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    // Visual system: restrained indigo + semantic status colors.
    static final int PRIMARY = Color.rgb(79,70,229), PRIMARY_DARK = Color.rgb(55,48,163);
    static final int SUCCESS = Color.rgb(22,163,74), SUCCESS_BG = Color.rgb(220,252,231);
    static final int ERROR = Color.rgb(220,38,38), ERROR_BG = Color.rgb(254,226,226);
    static final int WARNING = Color.rgb(217,119,6), WARNING_BG = Color.rgb(255,247,214);
    static final int TEXT = Color.rgb(31,32,43), MUTED = Color.rgb(103,108,125);
    static final int BG = Color.rgb(246,247,251), SURFACE = Color.rgb(241,242,247), CARD = Color.WHITE;
    static final int BORDER = Color.rgb(226,228,236);

    static final String LEGACY_PREF = "task_tracker_v4";
    static final String OLD_PREF_V3 = "task_tracker_v3", OLD_PREF_V2 = "v2", OLD_PREF_V1 = "tasks";
    static final String OLD_DB_NAME = "task_tracker_v19.db";

    LinearLayout root, content, nav;
    ScrollView scroll;
    TextView title, summary;
    TaskDbHelper db;
    ArrayList<Task> tasks = new ArrayList<>();
    Calendar monthCursor = Calendar.getInstance();
    final SimpleDateFormat dayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    final SimpleDateFormat niceDate = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.US);
    String selectedDate;
    int currentTab = 0;
    String taskFilter = "All";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedDate = todayKey();
        setupWindow();
        db = new TaskDbHelper(this);
        migratePreviousDatabaseIfPresent();
        migrateLegacyIfNeeded();
        tasks.addAll(db.loadTasks());
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 500);
        }
        buildShell();
        showToday();
        scheduleAllReminders();
    }

    void setupWindow() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
        } else {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView tv(String s, float sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(TEXT); t.setIncludeFontPadding(false);
        return t;
    }
    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(TEXT);
        b.setGravity(Gravity.CENTER); b.setPadding(dp(8),0,dp(8),0); b.setMinHeight(dp(44));
        b.setStateListAnimator(null); b.setBackground(round(SURFACE,dp(15)));
        return b;
    }
    GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    GradientDrawable outline(int fill, int stroke, int radius) { GradientDrawable g = round(fill,radius); g.setStroke(dp(1),stroke); return g; }

    void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setClipChildren(false); root.setClipToPadding(false);
        root.setPadding(dp(12),0,dp(12),0);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = dp(8), bottom = dp(8);
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top + dp(6); bottom = bars.bottom + dp(6);
            }
            v.setPadding(dp(12),top,dp(12),bottom);
            return insets;
        });

        LinearLayout appbar = new LinearLayout(this);
        appbar.setGravity(Gravity.CENTER_VERTICAL);
        appbar.setPadding(0,0,0,dp(3));
        Button menu = button("☰"); menu.setTextSize(22); menu.setBackground(round(Color.TRANSPARENT,0));
        menu.setOnClickListener(v -> showMore());
        appbar.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(58)));
        title = tv("Today",25); title.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); title.setGravity(Gravity.CENTER);
        appbar.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button quick = button("＋"); quick.setTextSize(28); quick.setTextColor(PRIMARY_DARK); quick.setBackground(round(Color.TRANSPARENT,0));
        quick.setOnClickListener(v -> editTask(-1));
        appbar.addView(quick,new LinearLayout.LayoutParams(dp(48),dp(58)));
        root.addView(appbar);

        summary = tv("",13.5f); summary.setTextColor(MUTED); summary.setGravity(Gravity.CENTER_VERTICAL);
        summary.setPadding(dp(14),0,dp(14),0); summary.setSingleLine(true); summary.setEllipsize(TextUtils.TruncateAt.END);
        summary.setBackground(round(SURFACE,dp(16)));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1,dp(42)); slp.setMargins(0,0,0,dp(8)); root.addView(summary,slp);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,0,0,dp(108));
        scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        nav = new LinearLayout(this); nav.setPadding(dp(4),dp(4),dp(4),dp(4)); nav.setBackground(round(CARD,dp(20))); nav.setElevation(dp(5));
        String[] names = {"Today","Month","Stats","Tasks","More"};
        for (int i=0;i<names.length;i++) {
            final int idx=i; Button n=button(names[i]); n.setTextSize(14); n.setBackground(round(Color.TRANSPARENT,dp(15)));
            n.setOnClickListener(v->{currentTab=idx; if(idx==0)showToday();else if(idx==1)showMonth();else if(idx==2)showStats();else if(idx==3)showTasks();else showMore();});
            nav.addView(n,new LinearLayout.LayoutParams(0,dp(52),1));
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(60)));
        setContentView(root); root.requestApplyInsets(); refreshNav();
    }

    void refreshNav() {
        if(nav==null)return;
        for(int i=0;i<nav.getChildCount();i++){
            Button b=(Button)nav.getChildAt(i); boolean on=i==currentTab;
            b.setTextColor(on?PRIMARY_DARK:MUTED); b.setTypeface(on?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
            b.setBackground(round(on?Color.rgb(232,231,255):Color.TRANSPARENT,dp(15)));
        }
    }

    void resetScroll() { if(scroll!=null){ scroll.post(() -> scroll.scrollTo(0,0)); } }
    void clearScreen(String h) { title.setText(h); content.removeAllViews(); content.setAlpha(1f); content.setTranslationY(0); updateSummary(selectedDate); refreshNav(); resetScroll(); }
    String todayKey(){ return dayKey.format(new Date()); }
    String keyFor(int y,int m,int d){ Calendar c=new GregorianCalendar(y,m,d); return dayKey.format(c.getTime()); }
    String nice(String k){ try{return niceDate.format(dayKey.parse(k));}catch(Exception e){return k;} }
    boolean isFuture(String k){ return k.compareTo(todayKey())>0; }

    String firstHistoryDate(Task t){ String first=""; for(String k:t.history.keySet()) if(first.isEmpty()||k.compareTo(first)<0)first=k; return first; }
    String effectiveActiveFrom(Task t){ if(t.activeFrom!=null&&!t.activeFrom.isEmpty())return t.activeFrom; String h=firstHistoryDate(t); return h.isEmpty()?todayKey():h; }
    boolean isApplicable(Task t,String date) {
        String start=effectiveActiveFrom(t); if(date.compareTo(start)<0) return false;
        try {
            Calendar d=Calendar.getInstance(); d.setTime(dayKey.parse(date));
            Calendar s=Calendar.getInstance(); s.setTime(dayKey.parse(start));
            if("Once".equalsIgnoreCase(t.repeat)) return sameDate(d,s);
            if("Weekly".equalsIgnoreCase(t.repeat)) return d.get(Calendar.DAY_OF_WEEK)==s.get(Calendar.DAY_OF_WEEK);
            if("Monthly".equalsIgnoreCase(t.repeat)) {
                int target=s.get(Calendar.DAY_OF_MONTH);
                int max=d.getActualMaximum(Calendar.DAY_OF_MONTH);
                return d.get(Calendar.DAY_OF_MONTH)==Math.min(target,max);
            }
            return true; // Daily and unknown rules.
        } catch(Exception e) { return true; }
    }
    boolean sameDate(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
    int total(String k){ if(isFuture(k)) return 0; int n=0; for(Task t:tasks) if(isApplicable(t,k)) n++; return n; }
    int yes(String k){ int n=0; for(Task t:tasks) if(isApplicable(t,k)&&t.status(k)==1)n++; return n; }
    int no(String k){ int n=0; for(Task t:tasks) if(isApplicable(t,k)&&t.status(k)==2)n++; return n; }
    int pending(String k){ if(isFuture(k))return 0; return Math.max(0,total(k)-yes(k)-no(k)); }
    int pct(String k){ int n=total(k); return n==0?0:Math.round(yes(k)*100f/n); }
    int monthAverage(int y,int m){ int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),s=0,n=0; for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}} return n==0?0:Math.round((float)s/n); }
    int applicableDays(Task t,int y,int m){ int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH), n=0; for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(!isFuture(k)&&isApplicable(t,k))n++;}return n; }
    int completedDays(Task t,int y,int m){ int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),n=0; for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(!isFuture(k)&&isApplicable(t,k)&&t.status(k)==1)n++;}return n; }
    int taskPct(Task t,int y,int m){int a=applicableDays(t,y,m);return a==0?0:Math.round(completedDays(t,y,m)*100f/a);}
    int perfectDays(int y,int m){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),n=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0&&pct(k)==100)n++;}return n;}
    void updateSummary(String k){ int total=total(k); summary.setText(nice(k)+"  •  "+yes(k)+" / "+total+" completed  •  "+pct(k)+"%  •  "+no(k)+" not completed  •  "+pending(k)+" pending"); }

    LinearLayout sectionTitle(String heading,String sub){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),dp(12),dp(4),dp(8));
        TextView h=tv(heading,22);h.setTypeface(Typeface.DEFAULT_BOLD);box.addView(h);
        if(sub!=null&&!sub.isEmpty()){TextView s=tv(sub,13);s.setTextColor(MUTED);s.setPadding(0,dp(3),0,0);box.addView(s);}
        return box;
    }
    void addGap(int h){content.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(h)));}
    TextView pill(String s,int bg,int fg){TextView p=tv(s,12);p.setTextColor(fg);p.setGravity(Gravity.CENTER);p.setPadding(dp(11),0,dp(11),0);p.setBackground(round(bg,dp(13)));return p;}

    int applicableTaskCount(String k){int n=0;for(Task t:tasks)if(isApplicable(t,k))n++;return n;}

    void showToday(){
        currentTab=0; selectedDate=todayKey(); clearScreen("Today");
        content.addView(buildDateNavigator(selectedDate)); addGap(8);
        content.addView(buildProgressCard(selectedDate),new LinearLayout.LayoutParams(-1,dp(150))); addGap(12);
        LinearLayout quickRow=new LinearLayout(this); quickRow.setGravity(Gravity.CENTER_VERTICAL);
        Button add=button("＋  Add task");add.setTextSize(15);add.setTextColor(Color.WHITE);add.setBackground(round(PRIMARY,dp(17)));add.setOnClickListener(v->editTask(-1));
        quickRow.addView(add,new LinearLayout.LayoutParams(0,dp(56),1));
        Button stats=button("Insights");stats.setTextSize(14);stats.setOnClickListener(v->showStats());
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(dp(108),dp(56));qlp.setMargins(dp(8),0,0,0);quickRow.addView(stats,qlp);
        content.addView(quickRow); addGap(14);
        LinearLayout headRow=new LinearLayout(this); headRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView head=tv("Today's tasks",21);head.setTypeface(Typeface.DEFAULT_BOLD);headRow.addView(head,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView count=pill(applicableTaskCount(selectedDate)+" scheduled",SURFACE,MUTED);headRow.addView(count,new LinearLayout.LayoutParams(dp(72),dp(32)));content.addView(headRow);addGap(7);
        int applicable=0;for(Task t:tasks)if(isApplicable(t,selectedDate))applicable++;
        if(applicable==0){ emptyState(); }
        for(Task t:tasks)if(isApplicable(t,selectedDate))addTodayTaskCard(t,selectedDate);
        addGap(6); content.addView(buildTodayInsightCard(selectedDate));
    }

    View buildDateNavigator(String date){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        Button prev=button("‹"); Button today=button(date.equals(todayKey())?"Today":"Today"); Button next=button("›");
        TextView d=tv(nice(date),17);d.setGravity(Gravity.CENTER);d.setTypeface(Typeface.DEFAULT_BOLD);
        prev.setOnClickListener(v->moveSelectedDay(-1)); today.setOnClickListener(v->{selectedDate=todayKey();showDay(selectedDate);});
        next.setOnClickListener(v->moveSelectedDay(1)); if(date.equals(todayKey()))next.setEnabled(false);
        row.addView(prev,new LinearLayout.LayoutParams(dp(54),dp(48))); row.addView(d,new LinearLayout.LayoutParams(0,dp(48),1));
        row.addView(today,new LinearLayout.LayoutParams(dp(82),dp(48))); row.addView(next,new LinearLayout.LayoutParams(dp(54),dp(48))); return row;
    }
    void moveSelectedDay(int delta){try{Calendar c=Calendar.getInstance();c.setTime(dayKey.parse(selectedDate));c.add(Calendar.DAY_OF_YEAR,delta);String k=dayKey.format(c.getTime());if(k.compareTo(todayKey())>0)k=todayKey();selectedDate=k;showDay(k);}catch(Exception ignored){}}
    void showDay(String date){currentTab=0;selectedDate=date;showSpecificDay(date);}
    void showSpecificDay(String date){clearScreen("Today");content.addView(buildDateNavigator(date));addGap(8);content.addView(buildProgressCard(date),new LinearLayout.LayoutParams(-1,dp(150)));addGap(12);Button monthly=button("←  Back to month");monthly.setOnClickListener(v->showMonth());content.addView(monthly,new LinearLayout.LayoutParams(-1,dp(46)));addGap(11);TextView h=tv(nice(date),21);h.setTypeface(Typeface.DEFAULT_BOLD);content.addView(h);addGap(6);int a=0;for(Task t:tasks)if(isApplicable(t,date))a++;if(a==0)emptyState();for(Task t:tasks)if(isApplicable(t,date))addTodayTaskCard(t,date);addGap(8);content.addView(buildTodayInsightCard(date));}

    View buildProgressCard(String k){
        LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(17),dp(13),dp(13),dp(13));card.setBackground(round(Color.rgb(239,239,255),dp(23)));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);
        TextView small=tv("DAILY PROGRESS",11);small.setTextColor(PRIMARY_DARK);small.setTypeface(Typeface.DEFAULT_BOLD);left.addView(small);
        TextView p=tv(pct(k)+"%",39);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextColor(PRIMARY_DARK);left.addView(p,new LinearLayout.LayoutParams(-2,dp(50)));
        TextView sub=tv(yes(k)+" completed  •  "+no(k)+" not done  •  "+pending(k)+" pending",12.5f);sub.setTextColor(MUTED);left.addView(sub);
        card.addView(left,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout donut=new LinearLayout(this);donut.setGravity(Gravity.CENTER);donut.addView(new CircularProgressView(this,pct(k)),new LinearLayout.LayoutParams(dp(102),dp(102)));card.addView(donut,new LinearLayout.LayoutParams(dp(108),-1));
        return card;
    }

    View buildTodayInsightCard(String k){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(15),dp(13),dp(15),dp(13));box.setBackground(outline(CARD,BORDER,dp(19)));
        TextView h=tv("Today at a glance",16);h.setTypeface(Typeface.DEFAULT_BOLD);box.addView(h);addInsightRow(box,"Completed",String.valueOf(yes(k)),SUCCESS);addInsightRow(box,"Not completed",String.valueOf(no(k)),ERROR);addInsightRow(box,"Pending",String.valueOf(pending(k)),MUTED);
        return box;
    }
    void addInsightRow(LinearLayout box,String label,String value,int color){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView l=tv(label,13);l.setTextColor(MUTED);r.addView(l,new LinearLayout.LayoutParams(0,dp(30),1));TextView v=tv(value,14);v.setTypeface(Typeface.DEFAULT_BOLD);v.setTextColor(color);r.addView(v,new LinearLayout.LayoutParams(dp(45),dp(30)));box.addView(r);}

    void addTodayTaskCard(Task t,String d){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(13),dp(11),dp(10),dp(10));card.setBackground(round(CARD,dp(21)));card.setElevation(dp(1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView star=tv(t.fav?"★":"☆",25);star.setTextColor(t.fav?WARNING:Color.rgb(165,170,182));star.setGravity(Gravity.CENTER);star.setOnClickListener(v->{t.fav=!t.fav;db.saveTask(t);showCurrent();});top.addView(star,new LinearLayout.LayoutParams(dp(42),dp(52)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(2),0,dp(4),0);
        TextView name=tv(t.name,18);name.setTypeface(Typeface.DEFAULT_BOLD);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);mid.addView(name);
        String rem=t.reminder==null||t.reminder.isEmpty()?"":("  •  ⏰ "+t.reminder);
        TextView meta=tv(t.category+"  •  "+t.priority+"  •  "+t.repeat+rem,12);meta.setTextColor(MUTED);meta.setMaxLines(1);meta.setEllipsize(TextUtils.TruncateAt.END);mid.addView(meta,new LinearLayout.LayoutParams(-1,dp(25)));
        top.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        Button menu=button("⋮");menu.setTextSize(20);menu.setBackground(round(SURFACE,dp(15)));menu.setOnClickListener(v->editTask(tasks.indexOf(t)));top.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(44)));card.addView(top);
        LinearLayout actions=new LinearLayout(this);actions.setPadding(dp(42),dp(7),0,0);
        int st=t.status(d);
        Button done=button(st==1?"✓ Done":"Done"), no=button(st==2?"✕ Not done":"Not done"), pending=button(st==0?"— Pending":"Clear");
        styleStatus(done,st==1,1);styleStatus(no,st==2,2);styleStatus(pending,st==0,0);
        done.setOnClickListener(v->changeStatus(t,d,1)); no.setOnClickListener(v->changeStatus(t,d,2)); pending.setOnClickListener(v->changeStatus(t,d,0));
        actions.addView(done,new LinearLayout.LayoutParams(0,dp(46),1));actions.addView(no,new LinearLayout.LayoutParams(0,dp(46),1));actions.addView(pending,new LinearLayout.LayoutParams(0,dp(46),1));card.addView(actions);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(9));content.addView(card,lp);
    }
    void styleStatus(Button b,boolean on,int type){int bg=type==1?(on?SUCCESS_BG:SURFACE):type==2?(on?ERROR_BG:SURFACE):(on?Color.rgb(233,234,240):SURFACE);b.setBackground(round(bg,dp(14)));b.setTextColor(on?(type==1?SUCCESS:type==2?ERROR:MUTED):TEXT);b.setTypeface(on?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);}
    void changeStatus(Task t,String d,int s){t.setStatus(d,s);db.setStatus(t.id,d,s);showCurrent();}
    void showCurrent(){if(currentTab==0) { if(selectedDate.equals(todayKey()))showToday(); else showSpecificDay(selectedDate); } else if(currentTab==1)showMonth();else if(currentTab==2)showStats();else if(currentTab==3)showTasks();else showMore();}

    void showMonth(){
        currentTab=1; int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clearScreen("Month");
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);Button prev=button("‹"),home=button("Current"),next=button("›");TextView mm=tv(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime()),20);mm.setGravity(Gravity.CENTER);mm.setTypeface(Typeface.DEFAULT_BOLD);
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);showMonth();});home.setOnClickListener(v->{monthCursor=Calendar.getInstance();showMonth();});next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);showMonth();});
        bar.addView(prev,new LinearLayout.LayoutParams(dp(52),dp(48)));bar.addView(mm,new LinearLayout.LayoutParams(0,dp(48),1));bar.addView(home,new LinearLayout.LayoutParams(dp(82),dp(48)));bar.addView(next,new LinearLayout.LayoutParams(dp(52),dp(48)));content.addView(bar);addGap(9);
        LinearLayout hero=new LinearLayout(this);hero.setGravity(Gravity.CENTER_VERTICAL);hero.setPadding(dp(16),dp(12),dp(15),dp(12));hero.setBackground(round(CARD,dp(21)));
        TextView av=tv(monthAverage(y,m)+"%",32);av.setTypeface(Typeface.DEFAULT_BOLD);av.setTextColor(PRIMARY_DARK);hero.addView(av,new LinearLayout.LayoutParams(dp(88),dp(70)));
        LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);TextView h1=tv("Monthly average",17);h1.setTypeface(Typeface.DEFAULT_BOLD);ht.addView(h1);TextView h2=tv("Average of elapsed days only. Future days are pending and excluded.",12);h2.setTextColor(MUTED);ht.addView(h2);hero.addView(ht,new LinearLayout.LayoutParams(0,-2,1));content.addView(hero);addGap(11);
        TextView hint=tv("Tap a date for daily details  •  swipe horizontally for all dates",12.5f);hint.setTextColor(MUTED);content.addView(hint);addGap(5);
        buildMatrix(y,m);
        addGap(13);content.addView(sectionTitle("Daily completion","Completed applicable tasks ÷ total applicable tasks for each elapsed day."));
        int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);content.addView(graphScroll(new MonthChart(this,y,m),Math.max(dp(1100),days*dp(48)),dp(285)),new LinearLayout.LayoutParams(-1,dp(305)));
        addGap(7);content.addView(sectionTitle("Task performance","Completed applicable days compared with the days on which each task could run."));
        content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(dp(900),tasks.size()*dp(145)),dp(290)),new LinearLayout.LayoutParams(-1,dp(310)));
        addGap(9);Button today=button("Go to today →");today.setTextColor(Color.WHITE);today.setTextSize(15);today.setBackground(round(PRIMARY,dp(16)));today.setOnClickListener(v->{monthCursor=Calendar.getInstance();selectedDate=todayKey();showToday();});content.addView(today,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void buildMatrix(int y,int m){
        int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);hsv.setHorizontalScrollBarEnabled(true);hsv.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        LinearLayout matrix=new LinearLayout(this);matrix.setOrientation(LinearLayout.VERTICAL);
        LinearLayout header=new LinearLayout(this);header.addView(matrixCell("TASK",dp(178),true),cellParams(dp(178),dp(60)));
        for(int d=1;d<=days;d++){
            String lab=d+"\n"+new SimpleDateFormat("EEE",Locale.US).format(new GregorianCalendar(y,m,d).getTime()).substring(0,3);
            Button b=button(lab);b.setTextSize(11.5f);b.setPadding(0,0,0,0);b.setTypeface(d==Calendar.getInstance().get(Calendar.DAY_OF_MONTH)&&y==Calendar.getInstance().get(Calendar.YEAR)&&m==Calendar.getInstance().get(Calendar.MONTH)?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
            final String k=keyFor(y,m,d);b.setOnClickListener(v->showDay(k)); if(k.equals(todayKey()))b.setBackground(outline(Color.rgb(238,238,255),PRIMARY,dp(13)));header.addView(b,cellParams(dp(73),dp(60)));
        }
        matrix.addView(header);
        if(tasks.isEmpty()){TextView e=tv("No tasks yet. Tap + to create your first task.",15);e.setTextColor(MUTED);e.setPadding(dp(12),dp(22),dp(12),dp(22));matrix.addView(e);}
        for(Task t:tasks){
            LinearLayout row=new LinearLayout(this);
            TextView n=matrixCell(t.name,dp(178),true);n.setTextSize(14.5f);n.setPadding(dp(12),0,dp(10),0);n.setMaxLines(2);n.setEllipsize(TextUtils.TruncateAt.END);n.setOnClickListener(v->showTaskMonth(t));row.addView(n,cellParams(dp(178),dp(66)));
            for(int d=1;d<=days;d++){String k=keyFor(y,m,d);Button b=button(matrixMark(t,k));int st=t.status(k);styleMatrixCell(b,st,isFuture(k)||!isApplicable(t,k));final String date=k;b.setOnClickListener(v->{if(isApplicable(t,date)&&!isFuture(date))chooseStatus(t,date);else if(isFuture(date))showDay(date);});row.addView(b,cellParams(dp(73),dp(66)));}
            matrix.addView(row);
        }
        hsv.addView(matrix);content.addView(hsv,new LinearLayout.LayoutParams(-1,-2));
    }
    TextView matrixCell(String s,int w,boolean bold){TextView t=tv(s,15);t.setGravity(Gravity.CENTER_VERTICAL);t.setBackgroundColor(Color.rgb(235,236,242));if(bold)t.setTypeface(Typeface.DEFAULT_BOLD);return t;}
    LinearLayout.LayoutParams cellParams(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    String matrixMark(Task t,String k){ if(!isApplicable(t,k))return "·"; if(isFuture(k))return "—"; int s=t.status(k);return s==1?"✓":s==2?"×":"—"; }
    void styleMatrixCell(Button b,int status,boolean inactive){int bg=inactive?Color.rgb(246,247,249):status==1?Color.rgb(222,248,231):status==2?Color.rgb(254,229,229):Color.rgb(244,245,248);b.setBackground(round(bg,dp(13)));b.setTextColor(inactive?Color.rgb(135,140,151):status==1?SUCCESS:status==2?ERROR:Color.rgb(80,85,96));b.setTextSize(22);}
    void chooseStatus(Task t,String k){if(!isApplicable(t,k)||isFuture(k))return;final String[] options={"✓  Completed","×  Not completed","—  Pending / clear"};new AlertDialog.Builder(this).setTitle(t.name).setItems(options,(d,w)->{int s=w==0?1:w==1?2:0;changeStatus(t,k,s);}).show();}
    void showTaskMonth(Task t){new AlertDialog.Builder(this).setTitle(t.name).setMessage("This task runs: "+t.repeat+"\nActive from: "+nice(effectiveActiveFrom(t))+"\nCurrent month completion: "+completedDays(t,monthCursor.get(Calendar.YEAR),monthCursor.get(Calendar.MONTH))+" / "+applicableDays(t,monthCursor.get(Calendar.YEAR),monthCursor.get(Calendar.MONTH))).setPositiveButton("OK",null).show();}

    void showStats(){
        currentTab=2; int y=monthCursor.get(Calendar.YEAR),m=monthCursor.get(Calendar.MONTH);clearScreen("Stats");
        TextView sub=tv(new SimpleDateFormat("MMMM yyyy",Locale.US).format(monthCursor.getTime())+" overview",14);sub.setTextColor(MUTED);sub.setPadding(dp(4),dp(4),dp(4),dp(5));content.addView(sub);
        LinearLayout cards=new LinearLayout(this);cards.setOrientation(LinearLayout.HORIZONTAL);cards.addView(statCard("MONTH AVG",monthAverage(y,m)+"%",PRIMARY),new LinearLayout.LayoutParams(0,dp(92),1));cards.addView(statCard("PERFECT DAYS",String.valueOf(perfectDays(y,m)),SUCCESS),new LinearLayout.LayoutParams(0,dp(92),1));cards.addView(statCard("TASKS",String.valueOf(tasks.size()),MUTED),new LinearLayout.LayoutParams(0,dp(92),1));content.addView(cards);addGap(11);
        content.addView(sectionTitle("Daily completion","Tap the Month tab to inspect each date."));int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);content.addView(graphScroll(new MonthChart(this,y,m),Math.max(dp(1100),days*dp(48)),dp(280)),new LinearLayout.LayoutParams(-1,dp(295)));
        addGap(10);content.addView(sectionTitle("Task performance","Completed applicable days / applicable days."));content.addView(graphScroll(new TaskComparisonChart(this,y,m),Math.max(dp(900),tasks.size()*dp(145)),dp(285)),new LinearLayout.LayoutParams(-1,dp(300)));
        addGap(9);content.addView(sectionTitle("Yearly monthly averages "+y,"Future months are shown as pending/empty, not as zero-performance months."));content.addView(new YearChart(this,y),new LinearLayout.LayoutParams(-1,dp(270)));
    }
    View statCard(String label,String value,int color){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(8),dp(8));c.setBackground(round(CARD,dp(18)));TextView l=tv(label,10);l.setTextColor(MUTED);c.addView(l);TextView v=tv(value,25);v.setTypeface(Typeface.DEFAULT_BOLD);v.setTextColor(color);c.addView(v,new LinearLayout.LayoutParams(-1,dp(42)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(92),1);lp.setMargins(dp(3),0,dp(3),0);c.setLayoutParams(lp);return c;}

    void showTasks(){
        currentTab=3;clearScreen("Tasks");
        LinearLayout searchRow=new LinearLayout(this);searchRow.setGravity(Gravity.CENTER_VERTICAL);EditText search=new EditText(this);search.setHint("Search tasks");search.setSingleLine(true);search.setTextSize(15);search.setBackground(round(CARD,dp(17)));search.setPadding(dp(14),0,dp(12),0);searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(58),1));Button plus=button("＋");plus.setTextSize(24);plus.setTextColor(Color.WHITE);plus.setBackground(round(PRIMARY,dp(16)));plus.setOnClickListener(v->editTask(-1));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(60),dp(58));pp.setMargins(dp(7),0,0,0);searchRow.addView(plus,pp);content.addView(searchRow);addGap(9);
        LinearLayout filters=new LinearLayout(this);filters.setBackground(round(SURFACE,dp(16)));String[] fs={"All","Favourites","High"};for(String f:fs){Button b=button(f);b.setTextSize(13);b.setOnClickListener(v->{taskFilter=f;showTasks();});b.setBackground(round(taskFilter.equals(f)?Color.rgb(232,231,255):Color.TRANSPARENT,dp(14)));b.setTextColor(taskFilter.equals(f)?PRIMARY_DARK:MUTED);filters.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));}content.addView(filters);addGap(8);
        LinearLayout info=new LinearLayout(this);info.setGravity(Gravity.CENTER_VERTICAL);TextView c=tv(taskCountText(),13);c.setTextColor(MUTED);info.addView(c,new LinearLayout.LayoutParams(0,dp(31),1));TextView add=tv("Sorted by name",12);add.setTextColor(MUTED);info.addView(add);content.addView(info);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);final String[] q={""};search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){q[0]=s.toString();renderTaskList(list,q[0]);}public void afterTextChanged(Editable e){}});renderTaskList(list,"");
    }
    String taskCountText(){int n=0;for(Task t:tasks){boolean ok=taskFilter.equals("All")||(taskFilter.equals("Favourites")&&t.fav)||(taskFilter.equals("High")&&"High".equals(t.priority));if(ok)n++;}return n+" task"+(n==1?"":"s");}
    void renderTaskList(LinearLayout list,String q){
        list.removeAllViews();q=q.toLowerCase(Locale.US);
        for(Task t:tasks){boolean match=t.name.toLowerCase(Locale.US).contains(q)||t.category.toLowerCase(Locale.US).contains(q);boolean filter=taskFilter.equals("All")||(taskFilter.equals("Favourites")&&t.fav)||(taskFilter.equals("High")&&"High".equals(t.priority));if(!match||!filter)continue;
            LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(11),dp(10),dp(8),dp(10));c.setBackground(round(CARD,dp(19)));
            TextView s=tv(t.fav?"★":"☆",23);s.setTextColor(t.fav?WARNING:Color.rgb(180,184,193));s.setGravity(Gravity.CENTER);s.setOnClickListener(v->{t.fav=!t.fav;db.saveTask(t);showTasks();});c.addView(s,new LinearLayout.LayoutParams(dp(43),dp(62)));
            LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView n=tv(t.name,16.5f);n.setTypeface(Typeface.DEFAULT_BOLD);n.setMaxLines(2);n.setEllipsize(TextUtils.TruncateAt.END);mid.addView(n);TextView m=tv(t.category+"  •  "+t.priority+"  •  "+t.repeat+(t.reminder.isEmpty()?"":"  •  "+t.reminder),12);m.setTextColor(MUTED);m.setMaxLines(1);m.setEllipsize(TextUtils.TruncateAt.END);mid.addView(m);c.addView(mid,new LinearLayout.LayoutParams(0,-2,1));Button e=button("EDIT");e.setTextSize(12);e.setOnClickListener(v->editTask(tasks.indexOf(t)));c.addView(e,new LinearLayout.LayoutParams(dp(70),dp(44)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(8));list.addView(c,lp);
        }
        if(list.getChildCount()==0){TextView e=tv("No matching tasks",15);e.setTextColor(MUTED);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(28),0,dp(28));list.addView(e);}
    }

    void showMore(){
        currentTab=4;clearScreen("More");
        TextView intro=tv("Personal preferences, data and app tools",14);intro.setTextColor(MUTED);intro.setPadding(dp(4),dp(3),dp(4),dp(10));content.addView(intro);
        addMoreButton("Backup & restore","Export or restore all tasks and history.",v->showBackupMenu());
        addMoreButton("Reminders","Set a daily notification time for any task.",v->showReminderInfo());
        addMoreButton("Statistics rules","See exactly how percentages are calculated.",v->showStatisticsRules());
        addMoreButton("Cloud / Login","Offline-first in this build; cloud sync can be added without changing your local history.",v->cloudInfo());
        addMoreButton("Appearance","Light theme, large touch targets, system-safe layout.",v->appearanceInfo());
        addMoreButton("About V20","Major UI, database, recurrence and statistics update.",v->aboutV20());
        Button clear=button("Clear all data");clear.setTextColor(ERROR);clear.setBackground(round(ERROR_BG,dp(16)));clear.setOnClickListener(v->confirmClearData());content.addView(clear,new LinearLayout.LayoutParams(-1,dp(50)));
    }
    void addMoreButton(String h,String sub,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(15),dp(13),dp(12),dp(11));c.setBackground(round(CARD,dp(18)));TextView a=tv(h,16);a.setTypeface(Typeface.DEFAULT_BOLD);c.addView(a);TextView b=tv(sub,12.5f);b.setTextColor(MUTED);b.setMaxLines(2);b.setEllipsize(TextUtils.TruncateAt.END);c.addView(b);c.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(76));lp.setMargins(0,0,0,dp(8));content.addView(c,lp);}

    void editTask(int ix){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(3),0,dp(3),0);
        EditText n=field("Task name");EditText c=field("Category");EditText note=field("Notes");note.setMinLines(3);note.setGravity(Gravity.TOP);Spinner p=spinner(new String[]{"High","Medium","Low"});Spinner r=spinner(new String[]{"Once","Daily","Weekly","Monthly"});
        Button active=button("Active from: "+nice(todayKey()));final String[] activeDate={todayKey()};final String[] rem={""};
        if(ix>=0){Task t=tasks.get(ix);n.setText(t.name);c.setText(t.category);note.setText(t.note);activeDate[0]=effectiveActiveFrom(t);rem[0]=t.reminder;active.setText("Active from: "+nice(activeDate[0]));String[] ps={"High","Medium","Low"},rs={"Once","Daily","Weekly","Monthly"};for(int i=0;i<ps.length;i++)if(ps[i].equals(t.priority))p.setSelection(i);for(int i=0;i<rs.length;i++)if(rs[i].equals(t.repeat))r.setSelection(i);}
        active.setOnClickListener(v->pickDate(active,activeDate));
        Button reminder=button(rem[0].isEmpty()?"⏰ Reminder: Off":"⏰ Reminder: "+rem[0]);reminder.setOnClickListener(v->pickReminder(reminder,rem));
        TextView rule=tv("Recurrence determines which dates count in daily/monthly percentages.",12);rule.setTextColor(MUTED);rule.setPadding(dp(2),dp(3),dp(2),dp(8));
        f.addView(n);f.addView(c);f.addView(p);f.addView(r);f.addView(active,new LinearLayout.LayoutParams(-1,dp(50)));f.addView(reminder,new LinearLayout.LayoutParams(-1,dp(50)));f.addView(note);f.addView(rule);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(ix<0?"Create task":"Edit task").setView(f).setPositiveButton("SAVE",null).setNegativeButton("CANCEL",null);
        if(ix>=0)b.setNeutralButton("DELETE",(d,w)->deleteTask(ix));
        AlertDialog dlg=b.create();dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String nn=n.getText().toString().trim();if(nn.isEmpty()){n.setError("Task name required");return;}String cc=c.getText().toString().trim();if(cc.isEmpty())cc="General";Task t;if(ix<0){t=new Task(UUID.randomUUID().toString(),nn,cc,p.getSelectedItem().toString(),r.getSelectedItem().toString(),note.getText().toString().trim(),rem[0],activeDate[0]);tasks.add(t);}else{t=tasks.get(ix);t.name=nn;t.category=cc;t.priority=p.getSelectedItem().toString();t.repeat=r.getSelectedItem().toString();t.note=note.getText().toString().trim();t.reminder=rem[0];t.activeFrom=activeDate[0];}db.saveTask(t);scheduleReminder(t);dlg.dismiss();showCurrent();}));dlg.show();
    }
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(false);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(SURFACE,dp(14)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,0,0,dp(8));e.setLayoutParams(lp);return e;}
    Spinner spinner(String[] data){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,data));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,0,0,dp(7));s.setLayoutParams(lp);return s;}
    void pickDate(Button b,String[] val){try{Calendar c=Calendar.getInstance();c.setTime(dayKey.parse(val[0]));DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{val[0]=keyFor(y,m,day);b.setText("Active from: "+nice(val[0]));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));d.show();}catch(Exception ignored){}}
    void pickReminder(Button b,String[] val){Calendar now=Calendar.getInstance();TimePickerDialog d=new TimePickerDialog(this,(v,h,m)->{val[0]=String.format(Locale.US,"%02d:%02d",h,m);b.setText("⏰ Reminder: "+val[0]);},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true);d.setTitle("Daily reminder time");d.setButton(DialogInterface.BUTTON_NEGATIVE,"OFF",(x,w)->{val[0]="";b.setText("⏰ Reminder: Off");});d.show();}
    void deleteTask(int ix){if(ix<0||ix>=tasks.size())return;Task t=tasks.get(ix);cancelReminder(t);db.deleteTask(t.id);tasks.remove(ix);showCurrent();}

    void showBackupMenu(){new AlertDialog.Builder(this).setTitle("Backup & restore").setItems(new String[]{"Export backup","Import backup"},(d,w)->{if(w==0)exportBackup();else importBackup();}).show();}
    void showStatisticsRules(){new AlertDialog.Builder(this).setTitle("Statistics rules").setMessage("Daily % = completed applicable tasks ÷ total applicable tasks for that date.\n\nFuture dates have 0 applicable total for reporting and are excluded from the monthly average.\n\nTask performance = completed applicable days ÷ applicable days in the selected month.\n\nOnce / Weekly / Monthly tasks only count on dates where they are scheduled.").setPositiveButton("OK",null).show();}
    void cloudInfo(){new AlertDialog.Builder(this).setTitle("Cloud / Login").setMessage("V20 is offline-first. No fake account or hidden online service is used. Export a backup to Drive or another storage provider. A real cloud sync can be connected later.").setPositiveButton("OK",null).show();}
    void appearanceInfo(){new AlertDialog.Builder(this).setTitle("Appearance").setMessage("V20 uses a light, high-contrast layout with large touch targets, semantic status colors, and system-bar-safe spacing. A dark theme can be added later without changing your task data.").setPositiveButton("OK",null).show();}
    void aboutV20(){new AlertDialog.Builder(this).setTitle("Task Tracker V20").setMessage("Major update: refined phone UI, safer insets, persistent SQLite storage with V19 migration, recurrence-aware calculations, improved matrix, statistics, search, backup tools and task editing.").setPositiveButton("OK",null).show();}
    void confirmClearData(){new AlertDialog.Builder(this).setTitle("Clear all data?").setMessage("This deletes every task and its history from this phone. Export a backup first if you need it later.").setNegativeButton("CANCEL",null).setPositiveButton("CLEAR",(d,w)->{db.clearAll();tasks.clear();showToday();}).show();}

    void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"TaskTracker_V20_Backup.txt");startActivityForResult(i,77);}
    void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,78);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==77){OutputStream out=getContentResolver().openOutputStream(data.getData());if(out==null)throw new IOException();out.write(exportText().getBytes("UTF-8"));out.close();Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();}else if(req==78){InputStream in=getContentResolver().openInputStream(data.getData());if(in==null)throw new IOException();BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l).append('\n');br.close();importText(sb.toString());Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();showCurrent();}}catch(Exception e){Toast.makeText(this,"Backup operation failed",Toast.LENGTH_SHORT).show();}}
    String exportText(){StringBuilder o=new StringBuilder("TASKTRACKER_V20\n");for(Task t:tasks){o.append(clean(t.id)).append('|').append(clean(t.name)).append('|').append(clean(t.category)).append('|').append(clean(t.priority)).append('|').append(clean(t.repeat)).append('|').append(clean(t.note)).append('|').append(t.fav?1:0).append('|').append(clean(t.reminder)).append('|').append(clean(effectiveActiveFrom(t))).append('|');boolean first=true;for(Map.Entry<String,Integer> e:t.history.entrySet()){if(!first)o.append(',');first=false;o.append(e.getKey()).append('=').append(e.getValue());}o.append('\n');}return o.toString();}
    String clean(String s){if(s==null)return "";return s.replace("\\","/").replace("|","/").replace("\n"," ").replace(",",";").replace("=","-");}
    void importText(String data){db.clearAll();tasks.clear();for(String line:data.split("\\n")){if(line.startsWith("TASKTRACKER_V20")||line.startsWith("TASKTRACKER_V19")||line.trim().isEmpty())continue;String[] p=line.split("\\|",-1);if(p.length<9)continue;String active="";String hist="";if(p.length>=10){active=p[8];hist=p[9];}else{hist=p[8];}Task t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],p[7],active);t.fav="1".equals(p[6]);if(!hist.isEmpty())for(String e:hist.split(",")){String[] q=e.split("=");if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}t.activeFrom=effectiveActiveFrom(t);db.saveTask(t);tasks.add(t);}scheduleAllReminders();}

    void migratePreviousDatabaseIfPresent(){
        if(db.countTasks()>0)return;
        File old=getDatabasePath(OLD_DB_NAME);if(!old.exists())return;
        SQLiteDatabase src=null;Cursor c=null;
        try{
            src=SQLiteDatabase.openDatabase(old.getPath(),null,SQLiteDatabase.OPEN_READONLY);
            c=src.rawQuery("SELECT id,name,category,priority,repeat_rule,note,fav,reminder FROM tasks",null);
            while(c.moveToNext()){
                Task t=new Task(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(7),"");t.fav=c.getInt(6)!=0;
                Cursor s=null;try{s=src.rawQuery("SELECT date,state FROM status WHERE task_id=? ORDER BY date ASC",new String[]{t.id});while(s.moveToNext())t.history.put(s.getString(0),s.getInt(1));}finally{if(s!=null)s.close();}
                t.activeFrom=effectiveActiveFrom(t);db.saveTask(t);
            }
        }catch(Exception ignored){}finally{if(c!=null)c.close();if(src!=null)src.close();}
    }
    void migrateLegacyIfNeeded(){if(db.countTasks()>0)return;String data=getSharedPreferences(LEGACY_PREF,MODE_PRIVATE).getString("data","");if(data.isEmpty())data=getSharedPreferences(OLD_PREF_V3,MODE_PRIVATE).getString("data","");if(data.isEmpty())data=getSharedPreferences(OLD_PREF_V2,MODE_PRIVATE).getString("data","");if(data.isEmpty())data=getSharedPreferences(OLD_PREF_V1,MODE_PRIVATE).getString("data","");if(data.isEmpty())return;try{parseLegacyIntoDb(data);}catch(Exception ignored){}}
    void parseLegacyIntoDb(String data){for(String line:data.split("\\n")){String[] p=line.split("\\|",-1);if(p.length<8)continue;Task t;if(p.length>=9){t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],p[7],"");t.fav="1".equals(p[6]);String hist=p[8];if(!hist.isEmpty())for(String e:hist.split(",")){String[] q=e.split("=");if(q.length==2)try{t.history.put(q[0],Integer.parseInt(q[1]));}catch(Exception ignored){}}}else{t=new Task(p[0],p[1],p[2],p[3],p[4],p[5],"","");t.fav="1".equals(p[7]);if("1".equals(p[6]))t.history.put(todayKey(),1);}t.activeFrom=effectiveActiveFrom(t);db.saveTask(t);}}

    void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel("task_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Task Tracker daily reminders");nm.createNotificationChannel(ch);}}
    int reminderId(Task t){return Math.abs(t.id.hashCode());}
    void scheduleAllReminders(){for(Task t:tasks)scheduleReminder(t);}
    void cancelReminder(Task t){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent in=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
    void scheduleReminder(Task t){cancelReminder(t);if(t.reminder==null||t.reminder.isEmpty())return;try{String[] q=t.reminder.split(":");Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(q[0]));c.set(Calendar.MINUTE,Integer.parseInt(q[1]));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);Intent in=new Intent(this,ReminderReceiver.class);in.putExtra("taskName",t.name);in.putExtra("taskId",t.id);PendingIntent pi=PendingIntent.getBroadcast(this,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}catch(Exception ignored){}}

    HorizontalScrollView graphScroll(View v,int width,int height){HorizontalScrollView h=new HorizontalScrollView(this);h.setFillViewport(false);h.setHorizontalScrollBarEnabled(true);FrameLayout f=new FrameLayout(this);f.addView(v,new FrameLayout.LayoutParams(width,height));h.addView(f,new HorizontalScrollView.LayoutParams(width,height));return h;}

    class CircularProgressView extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int value;CircularProgressView(Context c,int v){super(c);value=v;}protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,rad=Math.min(getWidth(),getHeight())/2f-dp(8);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(9));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(218,219,235));c.drawCircle(cx,cy,rad,p);if(value>0){p.setColor(PRIMARY);c.drawArc(cx-rad,cy-rad,cx+rad,cy+rad,-90,360*value/100f,false,p);}p.setStyle(Paint.Style.FILL);p.setColor(PRIMARY_DARK);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(18));c.drawText(value+"%",cx,cy+dp(6),p);p.setTextAlign(Paint.Align.LEFT);}}

    class MonthChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;MonthChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setLayerType(View.LAYER_TYPE_HARDWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(CARD);int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH);float l=dp(48),t=dp(36),r=getWidth()-dp(22),b=getHeight()-dp(42);for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));p.setStrokeWidth(dp(1));c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(dp(10));c.drawText((q*25)+"%",dp(6),yy+dp(4),p);}float slot=(r-l)/Math.max(1,days);ArrayList<Float> xs=new ArrayList<>(),ys=new ArrayList<>();for(int d=1;d<=days;d++){String k=keyFor(y,m,d);float x=l+(d-.5f)*slot;int v=pct(k);float yy=b-(b-t)*v/100f;xs.add(x);ys.add(yy);}p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(PRIMARY);Path path=new Path();boolean started=false;float prevX=0,prevY=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)<=0)continue;float x=xs.get(d-1),yy=ys.get(d-1);if(!started){path.moveTo(x,yy);started=true;}else{float mid=(prevX+x)/2f;path.cubicTo(mid,prevY,mid,yy,x,yy);}prevX=x;prevY=yy;}if(started)c.drawPath(path,p);p.setStyle(Paint.Style.FILL);for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)<=0)continue;int v=pct(k);float x=xs.get(d-1),yy=ys.get(d-1);p.setColor(v>=75?SUCCESS:v>=40?WARNING:v>0?ERROR:Color.rgb(155,159,170));c.drawCircle(x,yy,dp(4),p);p.setColor(TEXT);p.setTextSize(dp(9));String lab=v+"%";c.drawText(lab,x-p.measureText(lab)/2f,Math.max(t+dp(12),yy-dp(8)),p);p.setColor(MUTED);String ds=String.valueOf(d);c.drawText(ds,x-p.measureText(ds)/2f,b+dp(17),p);}p.setColor(MUTED);p.setTextSize(dp(10));c.drawText("Daily completion • completed ÷ applicable total",l,dp(16),p);}}

    class TaskComparisonChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y,m;int[] colors={Color.rgb(59,130,246),Color.rgb(16,185,129),Color.rgb(245,158,11),Color.rgb(239,68,68),Color.rgb(139,92,246),Color.rgb(14,165,233),Color.rgb(236,72,153)};TaskComparisonChart(Context c,int yy,int mm){super(c);y=yy;m=mm;setLayerType(View.LAYER_TYPE_HARDWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(CARD);float l=dp(45),t=dp(28),r=getWidth()-dp(16),b=getHeight()-dp(58);for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(dp(10));c.drawText((q*25)+"%",dp(5),yy+dp(4),p);}if(tasks.isEmpty()){p.setColor(MUTED);p.setTextSize(dp(14));c.drawText("Add tasks to see performance.",l,t+dp(25),p);return;}float slot=(r-l)/Math.max(1,tasks.size()),bw=Math.min(dp(82),slot*.58f);for(int i=0;i<tasks.size();i++){Task task=tasks.get(i);int done=completedDays(task,y,m),app=applicableDays(task,y,m),v=app==0?0:Math.round(done*100f/app);float x=l+i*slot+(slot-bw)/2f,h=(b-t)*v/100f;p.setColor(colors[i%colors.length]);c.drawRoundRect(x,b-h,x+bw,b,dp(12),dp(12),p);p.setColor(TEXT);p.setTextSize(dp(10));String val=done+"/"+app+"  "+v+"%";c.drawText(val,x+bw/2f-p.measureText(val)/2f,Math.max(t+dp(11),b-h-dp(7)),p);p.setTextSize(dp(9));String nm=task.name.length()>11?task.name.substring(0,10)+"…":task.name;c.drawText(nm,x+bw/2f-p.measureText(nm)/2f,b+dp(18),p);}}}

    class YearChart extends View {Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int y;YearChart(Context c,int yy){super(c);y=yy;}protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(CARD);float l=dp(34),t=dp(18),r=getWidth()-dp(12),b=getHeight()-dp(38);for(int q=0;q<=4;q++){float yy=b-(b-t)*q/4f;p.setColor(Color.rgb(229,231,235));c.drawLine(l,yy,r,yy,p);p.setColor(MUTED);p.setTextSize(dp(9));c.drawText((q*25)+"%",dp(4),yy+dp(3),p);}float slot=(r-l)/12f,bw=slot*.55f;for(int m=0;m<12;m++){int days=new GregorianCalendar(y,m,1).getActualMaximum(Calendar.DAY_OF_MONTH),s=0,n=0;for(int d=1;d<=days;d++){String k=keyFor(y,m,d);if(total(k)>0){s+=pct(k);n++;}}int v=n==0?0:Math.round(s/(float)n);float x=l+m*slot+(slot-bw)/2f,h=(b-t)*v/100f;p.setColor(v==0?Color.rgb(238,239,243):PRIMARY);if(v>0)c.drawRoundRect(x,b-h,x+bw,b,dp(9),dp(9),p);else c.drawRoundRect(x,b-dp(3),x+bw,b,dp(9),dp(9),p);p.setColor(MUTED);p.setTextSize(dp(8));String mon=new SimpleDateFormat("MMM",Locale.US).format(new GregorianCalendar(y,m,1).getTime());c.drawText(mon,x+bw/2f-p.measureText(mon)/2f,b+dp(15),p);if(v>0){c.drawText(String.valueOf(v),x+bw/2f-p.measureText(String.valueOf(v))/2f,b-h-dp(4),p);}}}}

    void emptyState(){LinearLayout e=new LinearLayout(this);e.setOrientation(LinearLayout.VERTICAL);e.setGravity(Gravity.CENTER);e.setPadding(dp(20),dp(30),dp(20),dp(30));TextView a=tv("No applicable tasks",19);a.setTypeface(Typeface.DEFAULT_BOLD);e.addView(a);TextView b=tv("Create a task or change its active date/recurrence.",13);b.setTextColor(MUTED);e.addView(b);content.addView(e,new LinearLayout.LayoutParams(-1,dp(120)));}
}
