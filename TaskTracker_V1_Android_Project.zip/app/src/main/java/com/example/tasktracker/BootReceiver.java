package com.example.tasktracker;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/** Recreates daily reminders after device restart or app replacement. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent trigger) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch=new NotificationChannel("task_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Task Tracker daily reminders");
            nm.createNotificationChannel(ch);
        }
        TaskDbHelper db=new TaskDbHelper(context);
        for (Task t:db.loadTasks()) schedule(context,t);
    }

    static int reminderId(Task t){return Math.abs(t.id.hashCode());}
    static void schedule(Context context,Task t){
        if(t.reminder==null||t.reminder.isEmpty())return;
        try{
            AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            Intent in=new Intent(context,ReminderReceiver.class);
            in.putExtra("taskName",t.name); in.putExtra("taskId",t.id);
            PendingIntent pi=PendingIntent.getBroadcast(context,reminderId(t),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            String[] q=t.reminder.split(":"); Calendar c=Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(q[0])); c.set(Calendar.MINUTE,Integer.parseInt(q[1])); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
        }catch(Exception ignored){}
    }
}
