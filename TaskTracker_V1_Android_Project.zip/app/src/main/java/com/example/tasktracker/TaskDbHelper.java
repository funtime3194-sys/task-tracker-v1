package com.example.tasktracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class TaskDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "task_tracker_v20.db";
    private static final int DB_VERSION = 2;

    public TaskDbHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); setWriteAheadLoggingEnabled(true); }

    @Override public void onConfigure(SQLiteDatabase db) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE tasks (id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, priority TEXT, repeat_rule TEXT, note TEXT, fav INTEGER NOT NULL DEFAULT 0, reminder TEXT, active_from TEXT)");
        db.execSQL("CREATE TABLE status (task_id TEXT NOT NULL, date TEXT NOT NULL, state INTEGER NOT NULL, PRIMARY KEY(task_id,date), FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_status_date ON status(date)");
        db.execSQL("CREATE INDEX idx_status_task ON status(task_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE tasks ADD COLUMN active_from TEXT");
            Cursor c = db.query("tasks", new String[]{"id"}, null, null, null, null, null);
            try {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    Cursor s = db.query("status", new String[]{"date"}, "task_id=?", new String[]{id}, null, null, "date ASC", "1");
                    String first = "";
                    try { if (s.moveToFirst()) first = s.getString(0); } finally { s.close(); }
                    ContentValues v = new ContentValues(); v.put("active_from", first);
                    db.update("tasks", v, "id=?", new String[]{id});
                }
            } finally { c.close(); }
        }
    }

    public int countTasks() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM tasks", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; } finally { c.close(); }
    }

    public ArrayList<Task> loadTasks() {
        ArrayList<Task> out = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        HashMap<String, HashMap<String,Integer>> allHistory = new HashMap<>();
        Cursor s = db.query("status", new String[]{"task_id","date","state"}, null, null, null, null, "date ASC");
        try {
            while (s.moveToNext()) {
                String id = s.getString(0);
                HashMap<String,Integer> h = allHistory.get(id);
                if (h == null) { h = new HashMap<>(); allHistory.put(id,h); }
                h.put(s.getString(1), s.getInt(2));
            }
        } finally { s.close(); }

        Cursor c = db.query("tasks", null, null, null, null, null, "name COLLATE NOCASE ASC");
        try {
            while (c.moveToNext()) {
                Task t = new Task(
                    c.getString(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("category")),
                    c.getString(c.getColumnIndexOrThrow("priority")),
                    c.getString(c.getColumnIndexOrThrow("repeat_rule")),
                    c.getString(c.getColumnIndexOrThrow("note")),
                    c.getString(c.getColumnIndexOrThrow("reminder")),
                    c.getString(c.getColumnIndexOrThrow("active_from"))
                );
                t.fav = c.getInt(c.getColumnIndexOrThrow("fav")) != 0;
                HashMap<String,Integer> h = allHistory.get(t.id);
                if (h != null) t.history.putAll(h);
                out.add(t);
            }
        } finally { c.close(); }
        return out;
    }

    public void saveTask(Task t) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("id", t.id); v.put("name", t.name); v.put("category", t.category); v.put("priority", t.priority);
            v.put("repeat_rule", t.repeat); v.put("note", t.note); v.put("fav", t.fav ? 1 : 0); v.put("reminder", t.reminder); v.put("active_from", t.activeFrom);
            db.insertWithOnConflict("tasks", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            db.delete("status", "task_id=?", new String[]{t.id});
            for (Map.Entry<String,Integer> e : t.history.entrySet()) {
                ContentValues s = new ContentValues(); s.put("task_id", t.id); s.put("date", e.getKey()); s.put("state", e.getValue());
                db.insertWithOnConflict("status", null, s, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void setStatus(String taskId, String date, int state) {
        SQLiteDatabase db = getWritableDatabase();
        if (state == 0) db.delete("status", "task_id=? AND date=?", new String[]{taskId, date});
        else {
            ContentValues v = new ContentValues(); v.put("task_id", taskId); v.put("date", date); v.put("state", state);
            db.insertWithOnConflict("status", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    public void deleteTask(String id) {
        getWritableDatabase().delete("tasks", "id=?", new String[]{id});
    }

    public void replaceAllTasks(ArrayList<Task> incoming) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("tasks", null, null);
            for (Task t : incoming) {
                ContentValues v = new ContentValues();
                v.put("id", t.id);
                v.put("name", t.name);
                v.put("category", t.category);
                v.put("priority", t.priority);
                v.put("repeat_rule", t.repeat);
                v.put("note", t.note);
                v.put("fav", t.fav ? 1 : 0);
                v.put("reminder", t.reminder);
                v.put("active_from", t.activeFrom);
                long inserted = db.insertOrThrow("tasks", null, v);
                if (inserted == -1) throw new IllegalStateException("Could not restore task " + t.name);
                for (Map.Entry<String,Integer> e : t.history.entrySet()) {
                    int state = e.getValue() == null ? 0 : e.getValue();
                    if (state < 1 || state > 2) continue;
                    ContentValues s = new ContentValues();
                    s.put("task_id", t.id);
                    s.put("date", e.getKey());
                    s.put("state", state);
                    db.insertOrThrow("status", null, s);
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void clearAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try { db.delete("tasks", null, null); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }
}
