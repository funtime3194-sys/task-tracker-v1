package com.example.tasktracker;

import java.util.HashMap;

public class Task {
    public String id;
    public String name;
    public String category;
    public String priority;
    public String repeat;
    public String note;
    public String reminder;
    public String activeFrom;
    public boolean fav;
    public HashMap<String,Integer> history = new HashMap<>();

    public Task(String id, String name, String category, String priority, String repeat, String note, String reminder) {
        this(id, name, category, priority, repeat, note, reminder, "");
    }

    public Task(String id, String name, String category, String priority, String repeat, String note, String reminder, String activeFrom) {
        this.id = id;
        this.name = name == null ? "Untitled task" : name;
        this.category = category == null || category.isEmpty() ? "General" : category;
        this.priority = priority == null || priority.isEmpty() ? "Medium" : priority;
        this.repeat = repeat == null || repeat.isEmpty() ? "Daily" : repeat;
        this.note = note == null ? "" : note;
        this.reminder = reminder == null ? "" : reminder;
        this.activeFrom = activeFrom == null ? "" : activeFrom;
    }

    public int status(String date) {
        Integer v = history.get(date);
        return v == null ? 0 : v;
    }

    public void setStatus(String date, int status) {
        if (status == 0) history.remove(date);
        else history.put(date, status);
    }
}
