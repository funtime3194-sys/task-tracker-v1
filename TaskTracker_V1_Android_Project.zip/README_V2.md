# Task Tracker V2

Personal offline-first Android task tracker.

## V2 changes
- Versioned JSON backup with full task data and daily history.
- Backward-compatible import for the older V19/V20 text backup formats.
- Backup is validated before current data is replaced.
- Full restore happens inside a SQLite transaction.
- Extra bottom scroll space keeps the last cards/charts reachable above navigation.
- Task search also matches notes.
- Task cards can be tapped to edit.
- Refreshed About/Data Summary text.
- App version 2.0 (versionCode 21).

Build with Gradle 8.9 and Java 17.
